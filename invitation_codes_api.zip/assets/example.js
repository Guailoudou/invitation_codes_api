console.log(blessing)
