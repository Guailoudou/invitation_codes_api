<?php

namespace InvitationCodeControllerApi;

class Configuration
{
    public function render()
    {
        //return view('xxx::config');
    }
}
